/**
 * Mafia Empire: Black Market Module
 * Элитные улучшения и глобальные множители дохода
 */

const MarketModule = {
    currentIndex: 0,
    station: {
        name: "BLACK MARKET",
        x: 0.75, // Позиция на карте (0.0 - 1.0)
        y: 0.85,
        upgrades: [
            { id: 'limo', name: "LIMOUSINE", desc: "STREET REPUTATION (+15% INCOME)", cost: 150000, multi: 1.15, msg: "REPUTATION UP!" },
            { id: 'heli', name: "HELICOPTER", desc: "AIR SUPPORT (+30% INCOME)", cost: 500000, multi: 1.30, msg: "SPEED REVENUE!" },
            { id: 'jet', name: "PRIVATE JET", desc: "GLOBAL REACH (+50% INCOME)", cost: 2000000, multi: 1.50, msg: "WORLD INFLUENCE!" },
            { id: 'yacht', name: "MEGA YACHT", desc: "ULTIMATE POWER (x2 INCOME)", cost: 10000000, multi: 2.00, msg: "GODFATHER STATUS!" }
        ]
    },

    // Отрисовка иконки черного рынка на канвасе
    draw(ctx) {
        const px = this.station.x * 1600;
        const py = this.station.y * 1600;
        const pulse = Math.sin(Date.now() / 400) * 8;
        
        ctx.save();
        ctx.translate(px, py);
        
        // Свечение
        ctx.shadowBlur = 20 + pulse;
        ctx.shadowColor = "#a742ff";
        
        // Ромб
        ctx.rotate(Math.PI / 4);
        ctx.fillStyle = "#a742ff";
        ctx.fillRect(-15, -15, 30, 30);
        
        // Текст
        ctx.rotate(-Math.PI / 4);
        ctx.fillStyle = "#fff";
        ctx.font = "bold 14px Arial";
        ctx.textAlign = "center";
        ctx.fillText("BM", 0, 5);
        
        ctx.restore();
    },

    // Проверка клика по маркету
    checkClick(wx, wy, state) {
        const px = this.station.x * 1600;
        const py = this.station.y * 1600;
        if (Math.hypot(wx - px, wy - py) < 50) {
            this.showMenu(state);
            return true;
        }
        return false;
    },

    // Логика меню в боковой панели
    showMenu(state) {
        state.selected = "BLACK_MARKET";
        const panel = document.getElementById('control-panel');
        const btn = document.getElementById('main-btn');
        
        // Если все куплено
        if (this.currentIndex >= this.station.upgrades.length) {
            this.renderSoldOut();
            return;
        }

        const item = this.station.upgrades[this.currentIndex];

        // Обновление текстовых полей HUD
        document.getElementById('district-name').innerText = item.name;
        document.getElementById('district-level').innerText = "ELITE LUXURY GOODS";
        
        const stats = document.getElementById('district-stats');
        stats.innerText = item.desc;
        stats.style.color = "#a742ff";

        const ownerLabel = document.getElementById('district-owner');
        ownerLabel.innerText = "BLACK MARKET";
        ownerLabel.style.color = "#a742ff";
        
        document.getElementById('district-counter').innerText = `UPGRADE ${this.currentIndex + 1} OF ${this.station.upgrades.length}`;

        panel.classList.add('active');

        // Настройка кнопки покупки
        btn.innerText = `BUY ${item.name}: $${item.cost.toLocaleString()}`;
        btn.disabled = state.money < item.cost;
        
        btn.onclick = () => this.buyItem(state, item);
    },

    buyItem(state, item) {
        if (state.money >= item.cost) {
            state.money -= item.cost;
            
            // Применяем глобальный множитель (создаем свойство, если его нет)
            state.globalMulti = (state.globalMulti || 1.0) * item.multi;
            
            // Эффект на карте
            if (typeof spawnText === 'function') {
                spawnText(this.station.x * 1600, this.station.y * 1600, item.msg, "#a742ff");
            }

            this.currentIndex++;
            
            // Обновляем статус или меню
            if (this.currentIndex < this.station.upgrades.length) {
                this.showMenu(state);
            } else {
                this.renderSoldOut();
            }
            
            // Обновляем визуальный ранг/статус если нужно
            if (typeof updateStatus === 'function') updateStatus();
        }
    },

    renderSoldOut() {
        const btn = document.getElementById('main-btn');
        document.getElementById('district-name').innerText = "MARKET CLOSED";
        document.getElementById('district-stats').innerText = "YOU OWN ALL ELITE ASSETS";
        btn.innerText = "MAX LEVEL REACHED";
        btn.disabled = true;
    }
};