/**
 * ИНТЕГРАЦИЯ TELEGRAM WEB APP
 * Модуль полностью очищен от нативных кнопок (MainButton).
 * Оставлены только системные функции: профиль, вибрация и управление окном.
 */

const tg = window.Telegram.WebApp;

const TelegramModule = {
    init() {
        tg.expand(); // Раскрыть приложение на весь экран
        tg.ready();
        
        // Установка визуального стиля системных элементов под игру
        tg.setHeaderColor('#050505');
        tg.setBackgroundColor('#050505');

        // ГАРАНТИЯ: Принудительно скрываем MainButton при инициализации
        if (tg.MainButton) {
            tg.MainButton.hide();
            tg.MainButton.isVisible = false;
        }

        this.initProfile();
        console.log("Telegram SDK: Native buttons removed. Profile & Haptics active.");
    },

    // Загрузка данных реального профиля игрока из Telegram
    initProfile() {
        const user = tg.initDataUnsafe?.user;
        
        if (user) {
            // Имя и фамилия
            const firstName = user.first_name || "";
            const lastName = user.last_name || "";
            const fullName = `${firstName} ${lastName}`.trim().toUpperCase();
            
            const nameElem = document.getElementById('user-name');
            if (nameElem) nameElem.innerText = fullName || "UNKNOWN BOSS";
            
            // ID пользователя (мафиозный номер)
            const statusElem = document.getElementById('user-status');
            if (statusElem) statusElem.innerText = `USER_ID: ${user.id}`;
            
            // Аватарка
            if (user.photo_url) {
                const photoElem = document.getElementById('user-photo');
                if (photoElem) photoElem.src = user.photo_url;
            }
        } else {
            // Если открыто не в Telegram (для тестов)
            const nameElem = document.getElementById('user-name');
            if (nameElem) nameElem.innerText = "LOCAL_OFFLINE_USER";
        }
    },

    /**
     * Вызывается при взаимодействии с объектами на карте.
     * Теперь здесь ТОЛЬКО тактильный отклик (вибрация).
     */
    updateContextButton(p, gameState) {
        // Убеждаемся, что нативная кнопка не вылезет программно
        if (tg.MainButton) {
            tg.MainButton.hide();
        }

        // Даем легкую вибрацию при клике на здание
        if (p) {
            this.triggerHaptic('light');
        }
    },

    /**
     * Нативная вибрация (важно для ощущения "дорогого" приложения)
     * @param {string} type - 'light', 'success', 'error', 'impact'
     */
    triggerHaptic(type = 'light') {
        if (!tg.HapticFeedback) return;
        switch(type) {
            case 'impact': tg.HapticFeedback.impactOccurred('medium'); break;
            case 'success': tg.HapticFeedback.notificationOccurred('success'); break;
            case 'error': tg.HapticFeedback.notificationOccurred('error'); break;
            case 'light': tg.HapticFeedback.selectionChanged(); break;
        }
    },

    // Системное уведомление (если понадобится)
    showNotice(msg) {
        tg.showAlert(msg);
    },

    // Системное подтверждение (например, перед крупной тратой)
    confirmAction(msg, callback) {
        tg.showConfirm(msg, (confirmed) => {
            if (confirmed) callback();
        });
    }
};

// Запуск инициализации при загрузке страницы
window.addEventListener('DOMContentLoaded', () => TelegramModule.init());