/**
 * Mafia Empire: Police Module
 * Управление уровнем розыска и взятками
 */
const PoliceModule = {
    station: {
        name: "POLICE STATION",
        x: 0.15, // Переместил в левый верхний угол, чтобы не мешать Рынку
        y: 0.45,
        baseBribe: 15000 // Базовая цена за одну звезду
    },

    drawStation(ctx, state) {
        const px = this.station.x * 1600;
        const py = this.station.y * 1600;

        ctx.save();
        ctx.translate(px, py);
        
        // Синее мерцание (эффект мигалки)
        const flash = Math.sin(Date.now() / 200) > 0;
        ctx.shadowBlur = 25;
        ctx.shadowColor = flash ? "#007aff" : "#ff3b30"; 
        
        // Значок щита
        ctx.fillStyle = "#007aff";
        ctx.beginPath();
        ctx.moveTo(0, -25);
        ctx.lineTo(20, -15);
        ctx.lineTo(20, 10);
        ctx.lineTo(0, 25);
        ctx.lineTo(-20, 10);
        ctx.lineTo(-20, -15);
        ctx.closePath();
        ctx.fill();
        
        // Текст PD
        ctx.fillStyle = "#fff";
        ctx.font = "bold 14px 'Courier New'";
        ctx.textAlign = "center";
        ctx.fillText("PD", 0, 5);
        
        ctx.restore();
    },

    checkClick(wx, wy, state) {
        const px = this.station.x * 1600;
        const py = this.station.y * 1600;
        if (Math.hypot(wx - px, wy - py) < 60) {
            this.showPoliceMenu(state);
            return true;
        }
        return false;
    },

    showPoliceMenu(state) {
        state.selected = "POLICE_STATION"; 
        const panel = document.getElementById('control-panel');
        const btn = document.getElementById('main-btn');
        
        // Расчет цены взятки (растет с каждой звездой)
        const currentBribe = this.station.baseBribe * state.wanted;

        document.getElementById('district-name').innerText = "CITY POLICE DEPT";
        document.getElementById('district-level').innerText = "CENTRAL STATION";
        document.getElementById('district-stats').innerText = "REDUCE HEAT";
        document.getElementById('district-owner').innerText = "GOVERNMENT";
        document.getElementById('district-owner').style.color = "#007aff";
        document.getElementById('district-security').innerText = "MAXIMUM";

        document.getElementById('district-counter').innerText = `WANTED LEVEL: ${"★".repeat(state.wanted)}${"☆".repeat(5-state.wanted)}`;

        panel.classList.add('active');

        if (state.wanted > 0) {
            btn.innerText = `PAY OFF POLICE: $${currentBribe.toLocaleString()}`;
            btn.disabled = state.money < currentBribe;
            btn.onclick = () => this.executeBribe(state, currentBribe);
        } else {
            btn.innerText = "NO CURRENT WANTED";
            btn.disabled = true;
            btn.onclick = null;
        }
    },

    executeBribe(state, cost) {
        if (state.money >= cost && state.wanted > 0) {
            state.money -= cost;
            state.wanted = 0; // Взятка полностью очищает репутацию
            
            if (typeof updateStatus === 'function') updateStatus();
            if (typeof spawnText === 'function') {
                spawnText(this.station.x * 1600, this.station.y * 1600, "RECORDS CLEARED", "#007aff");
            }
            
            // Закрываем панель или обновляем меню
            this.showPoliceMenu(state);
        }
    }
};