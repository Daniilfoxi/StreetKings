    const canvas = document.getElementById('gameCanvas');
    const ctx = canvas.getContext('2d');
    const mapImg = new Image();
    mapImg.src = 'maps.jpg';

    const ECON = {
        UPGRADE_MULT: 1.6,     // На сколько умножаем стоимость апгрейда
        INCOME_MULT: 1.4,      // На сколько растет доход при апгрейде
        DISTRICT_BONUS: 1.5,   // Множитель за полный контроль района
        WANTED_PENALTY: 0.05   // Штраф 5% от баланса при рейде за каждую звезду
    };

    let state = {
        money: 1500,
        wanted: 0,
        selected: null,
        cam: { x: 0, y: 0, z: 1, vx: 0, vy: 0 },
        touch: { lastX: 0, lastY: 0, dist: 0, dragging: false },
        time: 0,
        districts: [
            { id: 'D1', name: "PORT SIDE", x: 0, y: 0, w: 0.5, h: 0.5 },
            { id: 'D2', name: "UPTOWN", x: 0.5, y: 0, w: 0.5, h: 0.5 },
            { id: 'D3', name: "INDUSTRIAL", x: 0, y: 0.5, w: 0.5, h: 0.5 },
            { id: 'D4', name: "SUBURBS", x: 0.5, y: 0.5, w: 0.5, h: 0.5 }
        ],
        points: [
            // ТИР 1: Начальные точки (Доход 1-2 монеты)
            { id: 4, name: "ТВОЯ ВИЛЛА", x: 0.5, y: 0.5, owner: 'player', cost: 0, income: 1, risk: 0, lvl: 1 },
            { id: 1, name: "ЧЕРНЫЙ ДОК", x: 0.15, y: 0.6, owner: 'enemy', cost: 150, income: 1, risk: 1, lvl: 1 },
            { id: 3, name: "СТАРЫЙ СКЛАД", x: 0.2, y: 0.31, owner: 'enemy', cost: 400, income: 1, risk: 1, lvl: 1 },
            { id: 9, name: "ВЕРФЬ ГУЧЧИ", x: 0.2, y: 0.85, owner: 'neutral', cost: 800, income: 2, risk: 1, lvl: 1 },

            // ТИР 2: Средний бизнес (Доход 3-5 монет)
            { id: 6, name: "МЯСНАЯ ЛАВКА", x: 0.4, y: 0.25, owner: 'enemy', cost: 2000, income: 3, risk: 1, lvl: 1 },
            { id: 11, name: "ПОДПОЛЬНЫЙ БОКС", x: 0.3, y: 0.7, owner: 'neutral', cost: 3500, income: 4, risk: 2, lvl: 1 },
            { id: 12, name: "ОФИС ГАЗЕТЫ", x: 0.65, y: 0.35, owner: 'enemy', cost: 5000, income: 5, risk: 2, lvl: 1 },

            // ТИР 3: Топ-бизнес (Доход 8-15 монет)
            { id: 5, name: "ОТЕЛЬ 'ИМПЕРИАЛ'", x: 0.75, y: 0.45, owner: 'neutral', cost: 12000, income: 8, risk: 3, lvl: 1 },
            { id: 8, name: "НОЧНОЙ КЛУБ", x: 0.85, y: 0.7, owner: 'enemy', cost: 25000, income: 10, risk: 3, lvl: 1 },
            { id: 10, name: "ТЕРМИНАЛ А", x: 0.9, y: 0.4, owner: 'enemy', cost: 50000, income: 15, risk: 4, lvl: 1 },
            { id: 7, name: "БАНК ПОРТА", x: 0.55, y: 0.15, owner: 'neutral', cost: 100000, income: 25, risk: 5, lvl: 1 },

            { id: 2, name: "КАЗИНО РОЯЛЬ", x: 0.8, y: 0.20, owner: 'neutral', cost: 10000, income: 0, risk: 2, lvl: 1 }
        ],
        particles: [],
        traffic: [] 
    };

    let gameCamera;

    const NewsManager = {
        feed: [
            "Цены на контрабанду в Порту резко выросли",
            "Местный шериф ищет новых информаторов",
            "Черный рынок: спрос на золото бьет рекорды",
            "Вилла Дона стала объектом слухов в прессе",
            "Полиция усиливает патрулирование жилых секторов",
            "Казино Рояль ждет крупных игроков сегодня ночью"
        ],
        
        showNext() {
            const ticker = document.getElementById('news-ticker');
            if (!ticker) return;

            // Если высокий розыск — новости только о погоне
            if (state.wanted >= 4) {
                ticker.innerText = "🚨 ОПАСНОСТЬ: ПОЛИЦИЯ ОБЪЯВИЛА ПЛАН ПЕРЕХВАТ!";
                ticker.style.color = "var(--red)";
            } else {
                const msg = this.feed[Math.floor(Math.random() * this.feed.length)];
                ticker.innerText = `LATEST NEWS: ${msg}`;
                ticker.style.color = "var(--gold)";
            }
            
            // Эффект появления
            ticker.style.opacity = 0;
            setTimeout(() => { ticker.style.opacity = 1; }, 100);
        },

        start() {
            this.showNext();
            setInterval(() => this.showNext(), 7000);
        }
    };

    const SaveSystem = {
        save() {
            const saveData = {
                money: state.money,
                wanted: state.wanted,
                // Сохраняем только важные данные о точках: кто владеет и какой уровень
                points: state.points.map(p => ({
                    id: p.id,
                    owner: p.owner,
                    lvl: p.lvl,
                    income: p.income // сохраняем текущий доход, так как он растет при апгрейдах
                })),
                lastSaveTime: Date.now()
            };
            localStorage.setItem('mafia_v2_save', JSON.stringify(saveData));
            console.log("Game Saved");
        },

        load() {
            const rawData = localStorage.getItem('mafia_v2_save');
            if (!rawData) return false;

            const data = JSON.parse(rawData);
            state.money = data.money;
            state.wanted = data.wanted;

            // Восстанавливаем состояние точек
            data.points.forEach(savedPoint => {
                const point = state.points.find(p => p.id === savedPoint.id);
                if (point) {
                    point.owner = savedPoint.owner;
                    point.lvl = savedPoint.lvl;
                    point.income = savedPoint.income;
                }
            });

            // Начисляем оффлайн доход (по желанию)
            this.calculateOfflineIncome(data.lastSaveTime);
            
            updateStatus();
            return true;
        },

        calculateOfflineIncome(lastTime) {
            if (!lastTime) return; // Если данных о времени нет (первый запуск), выходим

            const now = Date.now();
            const secondsOffline = Math.floor((now - lastTime) / 1000);

            // Минимальный порог — 10 секунд, чтобы не спамить алертом при перезагрузке
            if (secondsOffline < 10) return;

            // Считаем суммарный доход всех точек игрока в секунду
            let incomePerSec = 0;
            state.points.forEach(p => {
                if (p.owner === 'player') {
                    // Здесь можно добавить проверку на бонус района, если хочешь
                    // Но для оффлайна обычно используют базовый доход (p.income)
                    incomePerSec += p.income;
                }
            });

            // Ограничение: начисляем доход максимум за 12 часов (43200 секунд)
            // Это мотивирует игрока заходить в игру хотя бы раз в день
            const cappedSeconds = Math.min(secondsOffline, 43200); 
            
            const totalEarned = Math.floor(incomePerSec * cappedSeconds);

            if (totalEarned > 0) {
                state.money += totalEarned;
                
                // Форматируем время для сообщения
                const hours = Math.floor(secondsOffline / 3600);
                const mins = Math.floor((secondsOffline % 3600) / 60);
                const timeStr = hours > 0 ? `${hours}ч. ${mins}м.` : `${mins}м.`;

                // Задержка алерта, чтобы игра успела прогрузиться визуально
                setTimeout(() => {
                    alert(`💰 КРИМИНАЛЬНЫЙ ОТЧЕТ\n\nТебя не было ${timeStr}.\nТвои предприятия принесли: $${totalEarned.toLocaleString()}\n\nДеньги добавлены на твой счет.`);
                    updateStatus(); // Обновляем интерфейс после закрытия окна
                }, 1200);
            }
        }
    };
        function init() {
            // 1. Сначала загружаем данные, чтобы state наполнился из памяти
            const loaded = SaveSystem.load();
            
            canvas.width = window.innerWidth;
            canvas.height = window.innerHeight;
            
            // Инициализация камеры (если скрипт камеры подключен)
            if(typeof GameCamera !== 'undefined') {
                gameCamera = new GameCamera(state, canvas, 1600, 1600);
            }
            
            // Настройка начального зума и центровки
            state.cam.z = Math.max(window.innerWidth / 1600, window.innerHeight / 1600);
            state.cam.x = (window.innerWidth - 1600 * state.cam.z) / 2;
            state.cam.y = (window.innerHeight - 1600 * state.cam.z) / 2;
            
            // --- УНИВЕРСАЛЬНЫЙ ОБРАБОТЧИК НАЖАТИЙ ---
            const handleInput = (e) => {
                // Если карта движется слишком быстро (инерция), игнорируем клик
                if (Math.abs(state.cam.vx) < 3 && Math.abs(state.cam.vy) < 3) {
                    let clientX, clientY;

                    if (e.changedTouches && e.changedTouches[0]) {
                        clientX = e.changedTouches[0].clientX;
                        clientY = e.changedTouches[0].clientY;
                    } else {
                        clientX = e.clientX;
                        clientY = e.clientY;
                    }
                    checkClick(clientX, clientY);
                }
            };

            canvas.addEventListener('touchend', handleInput);
            canvas.addEventListener('click', handleInput);

            // 2. Запускаем системы города
            NewsManager.start(); 
            
            // Создаем трафик (машинки)
            for(let i=0; i<30; i++) spawnCar();
            
            // Интервал проверки на облаву полиции (каждые 15 сек)
            setInterval(policeRaid, 15000); 
            
            // 3. АВТОСОХРАНЕНИЕ: Каждую минуту записываем прогресс в localStorage
            setInterval(() => {
                SaveSystem.save();
            }, 60000);

            // 4. Обновляем интерфейс и запускаем игровой цикл
            updateStatus();
            loop();
            
            console.log(loaded ? "Прогресс восстановлен" : "Начата новая игра");
        }

    function spawnCar() {
        state.traffic.push({
            x: Math.random() * 1600, y: Math.random() * 1600,
            speed: 0.4 + Math.random() * 1.2,
            angle: Math.random() * Math.PI * 2,
            color: Math.random() > 0.3 ? '#ffffff' : '#d4af37'
        });
    }

    function updateWorld() {
        state.traffic.forEach(car => {
            car.x += Math.cos(car.angle) * car.speed;
            car.y += Math.sin(car.angle) * car.speed;
            if(car.x < 0) car.x = 1600; if(car.x > 1600) car.x = 0;
            if(car.y < 0) car.y = 1600; if(car.y > 1600) car.y = 0;
        });
    }

    function checkClick(sx, sy) {
        const wx = (sx - state.cam.x) / state.cam.z;
        const wy = (sy - state.cam.y) / state.cam.z;
        
        // КАЗИНО ТЕПЕРЬ ПРОСТО ОТКРЫВАЕТСЯ
        const casinoPoint = state.points.find(p => p.id === 2);
        if (casinoPoint && Math.hypot(wx - casinoPoint.x * 1600, wy - casinoPoint.y * 1600) < 60) {
            CasinoModule.open(); 
            return; 
        }

        if (typeof PoliceModule !== 'undefined' && PoliceModule.checkClick(wx, wy, state)) {
            state.selected = "POLICE_STATION"; 
            return; 
        }
        if (typeof MarketModule !== 'undefined' && MarketModule.checkClick(wx, wy, state)) {
            state.selected = "BLACK_MARKET";
            return;
        }

        let found = false;
        state.points.forEach(p => {
            // Казино (id 2) пропускаем в общем цикле кликов по точкам захвата
            if (p.id !== 2 && Math.hypot(wx - p.x * 1600, wy - p.y * 1600) < 60) {
                state.selected = p;
                found = true;
                updatePanel(p);
            }
        });

        if (!found) {
            document.getElementById('control-panel').classList.remove('active');
            state.selected = null;
            TelegramModule.updateContextButton(null);
        }
    }

    function updatePanel(p) {
        if (!p || p === "POLICE_STATION" || p === "BLACK_MARKET" || p.x === undefined) return;

        const panel = document.getElementById('control-panel');
        const btn = document.getElementById('main-btn');
        const ownerLabel = document.getElementById('district-owner');
        const counterLabel = document.getElementById('district-counter');
        const districtLevelElem = document.getElementById('district-level');

        // 1. Определяем район и прогресс
        const currentDist = state.districts.find(d => p.x >= d.x && p.x < d.x+d.w && p.y >= d.y && p.y < d.y+d.h);
        
        if (currentDist) {
            const ptsInDist = state.points.filter(pt => 
                pt.id !== 2 && 
                pt.x >= currentDist.x && pt.x < currentDist.x+currentDist.w && 
                pt.y >= currentDist.y && pt.y < currentDist.y+currentDist.h
            );
            const ownedInDist = ptsInDist.filter(pt => pt.owner === 'player').length;
            
            document.getElementById('district-name').innerText = p.name;
            // Показываем уровень точки в заголовке
            districtLevelElem.innerText = `LEVEL: ${p.lvl}${p.lvl >= 10 ? ' (MAX)' : ''}`;
            counterLabel.innerText = `DISTRICT PROGRESS: ${ownedInDist}/${ptsInDist.length}`;
        }

        // 2. Инфо о доходе и владельце
        document.getElementById('district-stats').innerText = `+$${Math.floor(p.income)}/sec`;
        ownerLabel.innerText = p.owner.toUpperCase();
        ownerLabel.style.color = p.owner === 'player' ? 'var(--green)' : (p.owner === 'enemy' ? 'var(--red)' : 'var(--gold)');
        
        panel.classList.add('active');

        // 3. Логика кнопок
        btn.style.display = 'block'; // По умолчанию показываем
        btn.disabled = false;

        if (p.id === 4) {
            // ВИЛЛА (Штаб) — можно оставить декоративной или разрешить качать
            ownerLabel.innerText = "YOUR HEADQUARTERS";
            btn.style.display = 'none'; 
        } else if (p.owner !== 'player') {
            // РЕЖИМ ЗАХВАТА
            btn.innerText = `CAPTURE: $${p.cost.toLocaleString()}`;
            btn.onclick = () => {
                handleSeize(p);
                updatePanel(p);
            };
            btn.disabled = state.money < p.cost;
        } else {
            // РЕЖИМ УЛУЧШЕНИЯ (Максимум 10 уровень)
            if (p.lvl < 10) {
                // Цена растет: базовая стоимость * 0.5 * уровень + 200
                const upCost = Math.floor(p.cost * 0.5 * p.lvl) + 200;
                btn.innerText = `UPGRADE (LVL ${p.lvl + 1}): $${upCost.toLocaleString()}`;
                btn.onclick = () => {
                    handleUpgrade(p, upCost); // Внутри handleUpgrade должно быть p.income += 1
                    updatePanel(p);
                };
                btn.disabled = state.money < upCost;
            } else {
                // МАКСИМАЛЬНЫЙ УРОВЕНЬ
                btn.innerText = "MAX LEVEL REACHED";
                btn.disabled = true;
                btn.style.background = "#333"; // Делаем кнопку визуально "выключенной"
            }
        }

        if (typeof TelegramModule !== 'undefined') {
            TelegramModule.updateContextButton(p, state);
        }
    }

    function handleSeize(p) {
        if(state.money < p.cost) return;
        state.money -= p.cost;
        p.owner = 'player';
        state.wanted = Math.min(state.wanted + p.risk, 5);
        updateStatus();
        updatePanel(p);
        spawnText(p.x*1600, p.y*1600, "TERRITORY SEIZED!", "#ffd700");
        SaveSystem.save();
    }

    function handleUpgrade(p, cost) {
        // 1. Проверка: хватает ли денег и не достигнут ли лимит в 10 уровней
        if (state.money < cost || p.lvl >= 10) return;
        
        // 2. Списание средств
        state.money -= cost;
        
        // 3. Повышение уровня
        p.lvl++;
        
        // 4. Линейное увеличение дохода (ровно на 1 монету за уровень)
        // Мы убираем p.income *= ECON.INCOME_MULT, чтобы избежать инфляции
        p.income += 1; 
        
        // 5. Обратная связь (вибрация Telegram)
        if (typeof TelegramModule !== 'undefined') {
            TelegramModule.triggerHaptic('success');
        }

        // 6. Визуальный эффект
        // Показываем новый уровень и точную прибавку к доходу
        spawnText(p.x * 1600, p.y * 1600, `LVL ${p.lvl}: +$1/sec`, "#4cd964");
        
        // 7. Обновление интерфейса и сохранение
        updatePanel(p);   // Обновляем текст и цену на кнопке
        updateStatus();  // Обновляем общий ранг и счетчики
        
        if (typeof SaveSystem !== 'undefined') {
            SaveSystem.save();
        }
    }

   function updateStatus() {
    // 1. Обновление звезд розыска
    const stars = "★".repeat(state.wanted) + "☆".repeat(5 - state.wanted);
    const wantedElem = document.getElementById('wanted-level');
    if (wantedElem) wantedElem.innerText = stars;
    
    // 2. Подсчет захваченных точек и районов
    const ownedPoints = state.points.filter(p => p.owner === 'player');
    const ownedCount = ownedPoints.length;
    
    const capturedDists = state.districts.filter(d => {
        const pts = state.points.filter(p => 
            p.id !== 2 && 
            p.x >= d.x && p.x < d.x + d.w && 
            p.y >= d.y && p.y < d.y + d.h
        );
        return pts.length > 0 && pts.every(p => p.owner === 'player');
    }).length;
    
    const distCounter = document.getElementById('district-counter');
    if (distCounter) {
        distCounter.innerText = `CONTROLLED DISTRICTS: ${capturedDists}/4`;
    }
    
    // 3. Логика рангов
    let rank = "STREET THUG";
    if (ownedCount >= 3) rank = "ENFORCER";
    if (ownedCount >= 6) rank = "CAPO";
    if (ownedCount >= 10) rank = "CITY DON";
    if (ownedCount >= 12) rank = "GODFATHER";

    // 4. Работа с профилем и отслеживание изменений
    const profileRank = document.getElementById('rank-display');
    
    if (profileRank) {
        const oldRank = profileRank.innerText; // Берем старый ранг прямо из профиля

        // Если ранг изменился (и это не первая загрузка)
        if (oldRank !== rank && oldRank !== "") {
            
            // 5. Эффекты Telegram
            if (typeof TelegramModule !== 'undefined') {
                TelegramModule.triggerHaptic('success');
            }
            
            // Визуальная вспышка при повышении ранга
            profileRank.style.transition = "0.3s";
            profileRank.style.background = "#d4af37"; // Золотой
            profileRank.style.color = "#000";
            
            setTimeout(() => {
                profileRank.style.background = "rgba(212, 175, 55, 0.1)";
                profileRank.style.color = "#d4af37";
            }, 1000);
        }

        // Обновляем текст ранга в профиле
        profileRank.innerText = rank;
    }
}
    function policeRaid() {
        // Шанс рейда зависит от звезд
        if (state.wanted > 0 && Math.random() * 6 < state.wanted) {
            // Штрафуем на % от текущих денег (чем ты богаче, тем больше платишь)
            const penaltyBase = state.money * (ECON.WANTED_PENALTY * state.wanted);
            const fine = Math.floor(penaltyBase + (state.wanted * 2000));
            
            state.money = Math.max(0, state.money - fine);
            state.wanted = 0; // Сбрасываем розыск после рейда
            
            updateStatus();
            alert(`🚨 ПОЛИЦЕЙСКАЯ ОБЛАВА! Вы потеряли $${fine.toLocaleString()} и все влияние в полиции.`);
        }
    }

    function spawnText(x, y, txt, color) {
        state.particles.push({x, y, a: 1, text: txt, color: color || "#fff"});
    }

    function drawWorld() {
        ctx.clearRect(0,0, canvas.width, canvas.height);
        ctx.save();
        ctx.translate(state.cam.x, state.cam.y);
        ctx.scale(state.cam.z, state.cam.z);

        ctx.drawImage(mapImg, 0, 0, 1600, 1600);
        
        if (typeof PoliceModule !== 'undefined') PoliceModule.drawStation(ctx, state);
        if (typeof MarketModule !== 'undefined') MarketModule.draw(ctx); 

        state.districts.forEach(d => {
            const dx = d.x * 1600, dy = d.y * 1600, dw = d.w * 1600, dh = d.h * 1600;
            // Игнорируем казино при проверке рамки района
            const pts = state.points.filter(p => p.id !== 2 && p.x >= d.x && p.x < d.x+d.w && p.y >= d.y && p.y < d.y+d.h);
            const captured = pts.length > 0 && pts.every(p => p.owner === 'player');
            
            ctx.strokeStyle = captured ? "rgba(76, 217, 100, 0.5)" : "rgba(212, 175, 55, 0.25)";
            ctx.lineWidth = 4;
            ctx.setLineDash([20, 15]);
            ctx.strokeRect(dx + 15, dy + 15, dw - 30, dh - 30);
            ctx.setLineDash([]);
            ctx.fillStyle = captured ? "#4cd964" : "rgba(212, 175, 55, 0.5)";
            ctx.font = "bold 40px Arial";
            ctx.fillText(d.name, dx + 40, dy + 70);
        });

        state.traffic.forEach(car => {
            ctx.fillStyle = car.color;
            ctx.fillRect(car.x, car.y, 5, 5);
        });

        state.points.forEach(p => {
            const px = p.x * 1600, py = p.y * 1600;

            ctx.save();
            ctx.translate(px, py);

            if (p.id === 2) {
                const bounce = Math.sin(Date.now() / 300) * 5; 
                ctx.shadowBlur = 25;
                ctx.shadowColor = "#d4af37";
                ctx.font = "40px Arial";
                ctx.textAlign = "center";
                ctx.textBaseline = "middle";
                ctx.fillText("🎰", 0, bounce);
            } else {
                ctx.rotate(Math.PI / 4);
                ctx.fillStyle = p.owner === 'player' ? '#4cd964' : (p.owner === 'enemy' ? '#ff3b30' : '#d4af37');
                ctx.shadowBlur = 15; 
                ctx.shadowColor = ctx.fillStyle;
                ctx.fillRect(-12, -12, 24, 24);

                if (state.selected === p) {
                    ctx.strokeStyle = "#fff"; 
                    ctx.lineWidth = 3; 
                    ctx.strokeRect(-18, -18, 36, 36);
                }
            }
            ctx.restore();
        });

        state.particles.forEach((p, i) => {
            p.y -= 1; p.a -= 0.01;
            ctx.globalAlpha = p.a; ctx.fillStyle = p.color;
            ctx.font = "bold 20px Courier New";
            ctx.fillText(p.text, p.x, p.y);
            if(p.a <= 0) state.particles.splice(i, 1);
        });
        ctx.globalAlpha = 1;
        ctx.restore();
    }

    let lastTime = performance.now();
    function loop() {
        const now = performance.now();
        const dt = (now - lastTime) / 1000; 
        lastTime = now;

        updateWorld();
        if(gameCamera) gameCamera.updateInertia();

        // НАЧИСЛЯЕМ ДОХОД
        state.points.forEach(p => {
            if (p.owner === 'player') {
                const d = state.districts.find(dist => p.x >= dist.x && p.x < dist.x + dist.w && p.y >= dist.y && p.y < dist.y + dist.h);
                
                let multiplier = 1.0;
                if (d) { // Проверка, что район найден
                    const ptsInDist = state.points.filter(pt => pt.id !== 2 && pt.x >= d.x && pt.x < d.x + d.w && pt.y >= d.y && pt.y < d.y + d.h);
                    const isBoosted = ptsInDist.length > 0 && ptsInDist.every(pt => pt.owner === 'player');
                    multiplier = isBoosted ? 1.5 : 1.0;
                }
                
                state.money += (p.income * multiplier) * dt;

                if (Math.random() > 0.997) {
                    spawnText(p.x * 1600, p.y * 1600, `+$${Math.floor(p.income * multiplier)}`, "#4cd964");
                }
            }
        });

        drawWorld();

        const cashElem = document.getElementById('cash');
        if (cashElem) {
            cashElem.innerText = Math.floor(state.money).toLocaleString();
        }

        requestAnimationFrame(loop);
    }

    mapImg.onload = init;

    const profileCard = document.getElementById('user-profile-card');
    if (profileCard) {
        profileCard.onclick = function() {
            this.classList.toggle('expanded');
        };
    }