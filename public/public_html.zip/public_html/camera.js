// camera.js - Универсальное управление (Мышь + Тач)
class GameCamera {
    constructor(state, canvas, mapWidth, mapHeight) {
        this.state = state;
        this.canvas = canvas;
        this.mapW = mapWidth;
        this.mapH = mapHeight;
        this.overflow = 150; 
        this.bindEvents();
    }

    applyConstraints() {
        const cam = this.state.cam;
        const minX = window.innerWidth - (this.mapW * cam.z);
        const minY = window.innerHeight - (this.mapH * cam.z);

        if (cam.x > this.overflow) cam.x = this.overflow;
        if (cam.y > this.overflow) cam.y = this.overflow;
        if (cam.x < minX - this.overflow) cam.x = minX - this.overflow;
        if (cam.y < minY - this.overflow) cam.y = minY - this.overflow;
    }

    updateInertia() {
        const cam = this.state.cam;
        const touch = this.state.touch;

        if (!touch.dragging) {
            cam.x += cam.vx;
            cam.y += cam.vy;
            cam.vx *= 0.92;
            cam.vy *= 0.92;
            this.applyElasticEffect();
            if (Math.abs(cam.vx) < 0.01) cam.vx = 0;
            if (Math.abs(cam.vy) < 0.01) cam.vy = 0;
            this.applyConstraints();
        }
    }

    applyElasticEffect() {
        const cam = this.state.cam;
        const minX = window.innerWidth - (this.mapW * cam.z);
        const minY = window.innerHeight - (this.mapH * cam.z);
        const friction = 0.15; 

        if (cam.x > 0) cam.x -= cam.x * friction;
        if (cam.y > 0) cam.y -= cam.y * friction;
        if (cam.x < minX) cam.x += (minX - cam.x) * friction;
        if (cam.y < minY) cam.y += (minY - cam.y) * friction;
    }

    bindEvents() {
        const canvas = this.canvas;
        const touch = this.state.touch;
        const cam = this.state.cam;

        // Отключаем контекстное меню (правую кнопку мыши)
        canvas.addEventListener('contextmenu', e => e.preventDefault());

        // --- ЛОГИКА ЧЕРЕЗ POINTER EVENTS (Универсально для всего) ---

        canvas.addEventListener('pointerdown', e => {
            // Разворачиваем WebApp в ТГ при первом касании
            if (window.Telegram && window.Telegram.WebApp) {
                window.Telegram.WebApp.expand();
            }

            // Захватываем указатель (чтобы не терять движение при выходе за пределы)
            canvas.setPointerCapture(e.pointerId);

            touch.dragging = true;
            touch.isActualClick = true;
            cam.vx = 0; 
            cam.vy = 0;
            touch.lastX = e.clientX;
            touch.lastY = e.clientY;
        });

        canvas.addEventListener('pointermove', e => {
            if (!touch.dragging) return;

            const dx = e.clientX - touch.lastX;
            const dy = e.clientY - touch.lastY;

            // Если сдвинули больше чем на 5 пикселей — это уже не клик, а движение
            if (Math.hypot(dx, dy) > 5) {
                touch.isActualClick = false;
            }

            cam.x += dx;
            cam.y += dy;
            cam.vx = dx;
            cam.vy = dy;

            touch.lastX = e.clientX;
            touch.lastY = e.clientY;
            this.applyConstraints();
        });

        canvas.addEventListener('pointerup', e => {
            touch.dragging = false;
            canvas.releasePointerCapture(e.pointerId);
        });

        canvas.addEventListener('pointercancel', e => {
            touch.dragging = false;
            canvas.releasePointerCapture(e.pointerId);
        });

        // --- ЗУМ КОЛЕСИКОМ (Для ПК) ---
        canvas.addEventListener('wheel', e => {
            e.preventDefault();
            const delta = e.deltaY > 0 ? 0.9 : 1.1;
            let newZ = cam.z * delta;
            const minZ = (window.innerWidth / this.mapW) * 0.8; 
            if (newZ >= minZ && newZ < 3) cam.z = newZ;
            this.applyConstraints();
        }, { passive: false });

        // --- ДВУПАЛЬЦЕВЫЙ ЗУМ (Для телефонов) ---
        canvas.addEventListener('touchmove', e => {
            if (e.touches.length === 2) {
                const d = Math.hypot(
                    e.touches[0].clientX - e.touches[1].clientX, 
                    e.touches[0].clientY - e.touches[1].clientY
                );
                if (!touch.dist) touch.dist = d;
                
                const zoomFactor = d / touch.dist;
                let newZ = cam.z * zoomFactor;
                const minZ = (window.innerWidth / this.mapW) * 0.8; 
                if (newZ >= minZ && newZ < 3) cam.z = newZ;
                touch.dist = d;
            }
        }, { passive: false });

        canvas.addEventListener('touchend', () => {
            touch.dist = 0;
        });
    }
}