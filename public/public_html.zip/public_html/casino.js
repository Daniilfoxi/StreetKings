/**
 * Mafia Empire: Casino Module
 * Логика для "Casino Royale"
 */

const CasinoModule = {
    // Открытие UI казино
    open() {
        const ui = document.getElementById('casino-ui');
        ui.style.display = 'flex';
        this.updateUI();
        this.log("ДОБРО ПОЖАЛОВАТЬ, БОСС", "var(--gold)");
    },

    // Закрытие UI
    close() {
        document.getElementById('casino-ui').style.display = 'none';
        // Очищаем результат при выходе
        document.getElementById('casino-result').innerText = "";
    },

    // Обновление цифр в интерфейсе казино
    updateUI() {
        const balanceEl = document.getElementById('casino-balance');
        balanceEl.innerText = `CASH: $${Math.floor(state.money).toLocaleString()}`;
    },

    // Вывод текста лога
    log(text, color) {
        const resEl = document.getElementById('casino-result');
        resEl.innerText = text;
        resEl.style.color = color || "white";
    },

    // Основная логика игры
    play(bet) {
        if (state.money < bet) {
            this.log("НЕДОСТАТОЧНО СРЕДСТВ!", "var(--red)");
            return;
        }

        // Блокируем кнопки на время "вращения" (опционально можно добавить класс)
        state.money -= bet;
        this.updateUI();
        this.log("СТАВКИ ПРИНЯТЫ...", "white");

        // Имитация задержки игры (800мс)
        setTimeout(() => {
            const roll = Math.random() * 100;
            let win = 0;
            let message = "";
            let color = "";

            if (roll > 98) {
                // Джекпот (2% шанс)
                win = bet * 10;
                message = `ДЖЕКПОТ! x10: +$${win.toLocaleString()}`;
                color = "var(--gold)";
            } else if (roll > 70) {
                // Обычный выигрыш (28% шанс)
                win = bet * 2;
                message = `ВЫИГРЫШ! x2: +$${win.toLocaleString()}`;
                color = "var(--green)";
            } else {
                // Проигрыш
                message = "ПРОИГРЫШ. ПОВЕЗЕТ В СЛЕДУЮЩИЙ РАЗ";
                color = "rgba(255,255,255,0.6)";
            }

            if (win > 0) {
                state.money += win;
                // Визуальный эффект всплывающего текста над казино на карте
                if (typeof spawnText === 'function') {
                    spawnText(0.8 * 1600, 0.20 * 1600, `+$${win}`, "#51ff00ff");
                }
            }

            this.log(message, color);
            this.updateUI();
            
            // Обновляем общий HUD денег
            document.getElementById('cash').innerText = Math.floor(state.money).toLocaleString();
        }, 600);
    }
};